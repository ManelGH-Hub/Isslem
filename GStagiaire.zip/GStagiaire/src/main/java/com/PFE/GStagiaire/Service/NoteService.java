package com.PFE.GStagiaire.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.PFE.GStagiaire.Entity.Note;
import com.PFE.GStagiaire.Entity.User;
import com.PFE.GStagiaire.Repository.NoteRepository;
import com.PFE.GStagiaire.Repository.UserRepository;

import java.util.List;

@Service
public class NoteService {

    @Autowired
    private NoteRepository noteRepository;

    public List<Note> getAllNotes() {
        return noteRepository.findAll();
    }

    public Note createOrUpdateNote(Note note) {
        return noteRepository.save(note);
    }
    public void deleteNoteById(Long id) {
        noteRepository.deleteById(id);
    }
    public int getTotalEncadrantNotes() {
        List<Note> allNotes = getAllNotes();
        int totalEncadrantNotes = 0;
        for (Note note : allNotes) {
            if (note.getEncadrantNote() != null && !note.getEncadrantNote().isEmpty()) {
                totalEncadrantNotes++;
            }
        }
        return totalEncadrantNotes;
    }

    public int getTotalStagiaireNotes() {
        List<Note> allNotes = getAllNotes();
        int totalStagiaireNotes = 0;
        for (Note note : allNotes) {
            if (note.getStagiaireNote() != null && !note.getStagiaireNote().isEmpty()) {
                totalStagiaireNotes++;
            }
        }
        return totalStagiaireNotes;
    }
   @Autowired 
   private UserRepository userRepository ;
    public Note createOrUpdateNote(Note note, Long encadrantId, Long stagiaireId) {
        if (encadrantId != null) {
            User encadrant = userRepository.findById(encadrantId).orElseThrow(() -> new RuntimeException("Encadrant not found"));
            note.setEncadrant(encadrant);
        }
        if (stagiaireId != null) {
            User stagiaire = userRepository.findById(stagiaireId).orElseThrow(() -> new RuntimeException("Stagiaire not found"));
            note.setStagiaire(stagiaire);
        }
        return noteRepository.save(note);
    }
    // Other methods as needed

	public static List<Note> getNoteByIdencadrant(Long idEncadrant) {
		// TODO Auto-generated method stub
		return null;
	}

	public static List<Note> getNotesByIdstagiaire(Long idStagiaire) {
		// TODO Auto-generated method stub
		return null;
	}

	public int getTotalEncadrantNotesById(Long idEncadrant) {
		// TODO Auto-generated method stub
		return 0;
	}

}

