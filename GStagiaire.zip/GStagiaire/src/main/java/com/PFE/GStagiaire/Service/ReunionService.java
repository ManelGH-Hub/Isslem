package com.PFE.GStagiaire.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.PFE.GStagiaire.Entity.Reunion;
import com.PFE.GStagiaire.Repository.ReunionsRepository;

import java.util.List;
import java.util.Optional;

@Service
public class ReunionService {

    @Autowired
    private ReunionsRepository reunionRepository;

    public Reunion createReunion(Reunion reunion) {
        return reunionRepository.save(reunion);
    }

    public List<Reunion> getAllReunions() {
        return reunionRepository.findAll();
    }

    public Reunion updateReunion(Reunion reunionToUpdate) {
        return reunionRepository.save(reunionToUpdate);
    }

    public Reunion getReunionById(Long id) {
        Optional<Reunion> reunionOptional = reunionRepository.findById(id);
        return reunionOptional.orElse(null);
    }

	public List<Reunion> getReunionsByIdencadrant(Long idEncadrant) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Reunion> getReunionsByIdstagiaire(Long idStagiaire) {
		// TODO Auto-generated method stub
		return null;
	}

	public long countAcceptedReunionsCreatedByEncadrant() {
		// TODO Auto-generated method stub
		return 0;
	}

	public long countRefusedReunionsCreatedByEncadrant() {
		// TODO Auto-generated method stub
		return 0;
	}

	public long countEncoursReunionsCreatedByEncadrant() {
		// TODO Auto-generated method stub
		return 0;
	}

	public long countAcceptedReunionsCreatedByStagiaire() {
		// TODO Auto-generated method stub
		return 0;
	}

	public long countRefusedReunionsCreatedByStagiaire() {
		// TODO Auto-generated method stub
		return 0;
	}

	public long countEncoursReunionsCreatedByStagiaire() {
		// TODO Auto-generated method stub
		return 0;
	}

	

	public long countAllReunionsCreatedByStagiaire() {
		// TODO Auto-generated method stub
		return 0;
	}

	public long countAllReunionsCreatedByEncadrant() {
		// TODO Auto-generated method stub
		return 0;
	}

	
}
