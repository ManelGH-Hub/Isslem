package com.PFE.GStagiaire.Service;
public class LoginRequest {
    private String login;
    private String password;

    // Getters and setters
    public String getlogin() {
        return login;
    }

    public void setlogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}










