package com.PFE.GStagiaire.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.PFE.GStagiaire.Entity.Note;
import com.PFE.GStagiaire.Service.NoteService;

import java.util.List;

@RestController
@RequestMapping("/api/notes")
public class NoteController {

    @Autowired
    private NoteService noteService;

    @GetMapping
    public ResponseEntity<List<Note>> getAllNotes() {
        List<Note> notes = noteService.getAllNotes();
        return new ResponseEntity<>(notes, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Note> createOrUpdateNote(@RequestBody Note note) {
        Note savedNote = noteService.createOrUpdateNote(note);
        return new ResponseEntity<>(savedNote, HttpStatus.CREATED);
    }
    
    @GetMapping("/totalEncadrantNotes/{idEncadrant}")
    public ResponseEntity<Integer> getTotalEncadrantNotesById(@PathVariable Long idEncadrant) {
        int totalEncadrantNotes = noteService.getTotalEncadrantNotesById(idEncadrant);
        return new ResponseEntity<>(totalEncadrantNotes, HttpStatus.OK);
    }

    @GetMapping("/totalStagiaireNotes")
    public ResponseEntity<Integer> getTotalStagiaireNotes(@PathVariable Long idEncadrant) {
        int totalEncadrantNotes = noteService.getTotalEncadrantNotesById(idEncadrant);
        return new ResponseEntity<>(totalEncadrantNotes, HttpStatus.OK);
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteNoteById(@PathVariable("id") Long id) {
        noteService.deleteNoteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    @PostMapping("/stagiaire/{stagiaireId}")
    public ResponseEntity<Note> createStagiaireNote(@RequestBody Note note, @PathVariable("stagiaireId") Long stagiaireId) {
        Note savedNote = noteService.createOrUpdateNote(note, stagiaireId, stagiaireId);
        if (savedNote != null) {
            return new ResponseEntity<>(savedNote, HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Gérer le cas où l'utilisateur n'est pas trouvé
        }
    }

    @PostMapping("/encadrant/{encadrantId}")
    public ResponseEntity<Note> createEncadrantNote(@RequestBody Note note, @PathVariable("encadrantId") Long encadrantId) {
        Note savedNote = noteService.createOrUpdateNote(note, encadrantId, encadrantId);
        if (savedNote != null) {
            return new ResponseEntity<>(savedNote, HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Gérer le cas où l'utilisateur n'est pas trouvé
        }
    }
    
    @GetMapping("/byidencadrant/{idEncadrant}")
    public ResponseEntity<List<Note>> getNotesByIdencadrant(@PathVariable Long idEncadrant) {
        List<Note> reunions = NoteService.getNoteByIdencadrant(idEncadrant);
        return new ResponseEntity<>(reunions, HttpStatus.OK);
    }

    @GetMapping("/byidstagiaire/{idStagiaire}")
    public ResponseEntity<List<Note>> getNotesByIdstagiaire(@PathVariable Long idStagiaire) {
        List<Note> reunions = NoteService.getNotesByIdstagiaire(idStagiaire);
        return new ResponseEntity<>(reunions, HttpStatus.OK);
    }

   

    // Other endpoints as needed
    
}
