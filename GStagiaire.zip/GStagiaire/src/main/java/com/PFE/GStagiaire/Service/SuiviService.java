package com.PFE.GStagiaire.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.stereotype.Service;

import com.PFE.GStagiaire.Entity.Suivi;
import com.PFE.GStagiaire.Entity.User;
import com.PFE.GStagiaire.Repository.SuiviRepository;
import com.PFE.GStagiaire.Repository.UserRepository;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class SuiviService {

    @Autowired
    private SuiviRepository suiviRepository;

    public List<Suivi> getAllSuivi() {
        return suiviRepository.findAll();
    }

    public Suivi getSuiviById(Long id) {
        return suiviRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Suivi not found with id: " + id));
    }

    public Suivi createSuivi(Suivi suivi) {
        return suiviRepository.save(suivi);
    }

    public Suivi updateSuivi(Long id, Suivi suiviDetails) {
        Suivi suivi = suiviRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Suivi not found with id: " + id));

        // Update suiviDetails attributes here

        return suiviRepository.save(suivi);
    }

    public void deleteSuivi(Long id) {
        Suivi suivi = suiviRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Suivi not found with id: " + id));

        suiviRepository.delete(suivi);
    }
    public List<Suivi> getSuiviByUserId(Long userId) {
        return suiviRepository.findByUser_UserId(userId);
    }
    @Autowired
    private UserRepository userRepository;
    public Suivi createSuiviByUserId(Long userId, Suivi suivi) {
        Optional<User> userOptional = userRepository.findById(userId);
        if (userOptional.isPresent()) {
            User user = userOptional.get();
            suivi.setUser(user);
            return suiviRepository.save(suivi);
        } else {
            throw new ResourceNotFoundException("User not found with id: " + userId);
        }
    }
    
    public int countPresencesByMonth(int month) {
        List<Suivi> allSuivis = getAllSuivi();
        int count = 0;
        for (Suivi suivi : allSuivis) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(suivi.getDate());
            int suiviMonth = calendar.get(Calendar.MONTH) + 1; // Les mois commencent à 0 dans Calendar
            if (suiviMonth == month && suivi.isPresent()) {
                count++;
            }
        }
        return count;
    }

    public int countAbsencesByMonth(int month) {
        List<Suivi> allSuivis = getAllSuivi();
        int count = 0;
        for (Suivi suivi : allSuivis) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(suivi.getDate());
            int suiviMonth = calendar.get(Calendar.MONTH) + 1; // Les mois commencent à 0 dans Calendar
            if (suiviMonth == month && suivi.isAbsent()) {
                count++;
            }
        }
        return count;
    }
    public void deleteSuiviByUserId(Long userId) {
        // Votre logique pour supprimer le suivi associé à l'utilisateur avec l'ID userId
        // Par exemple :
        // suiviRepository.deleteByUserId(userId);
    }

    }
    


